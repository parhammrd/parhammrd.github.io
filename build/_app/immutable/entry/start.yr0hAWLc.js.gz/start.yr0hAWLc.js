import{a as t}from"../chunks/DbMy3DKi.js";export{t as start};
